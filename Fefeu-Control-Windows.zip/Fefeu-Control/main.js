const { app, BrowserWindow, ipcMain } = require('electron');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const TEMP_DIRS = [os.tmpdir(), path.join(process.env.SystemRoot || 'C:\\Windows', 'Temp')];

function ps(script, timeout = 60000) {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { timeout, windowsHide: true }, (err, out, errOut) => resolve({ ok: !err, out: (out || '').trim(), err: (errOut || (err && err.message) || '').trim() }));
  });
}

// ---------- CPU / RAM (nativo) ----------
let lastCpu = os.cpus().map(c => ({ ...c.times }));
function cpuLoad() {
  const now = os.cpus().map(c => ({ ...c.times }));
  let idle = 0, total = 0;
  now.forEach((t, i) => {
    const p = lastCpu[i];
    const d = Object.keys(t).reduce((a, k) => a + (t[k] - p[k]), 0);
    idle += t.idle - p.idle; total += d;
  });
  lastCpu = now;
  return total ? Math.round((1 - idle / total) * 100) : 0;
}

// ---------- Disco / Rede / GPU (WMI, independe do idioma do Windows) ----------
let extra = { Disco: 0, Rede: 0, GPU: 0 };
const EXTRA_SCRIPT = `
$d=(Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'").PercentDiskTime
$n=(Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface | Measure-Object BytesTotalPersec -Sum).Sum
$g=(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction SilentlyContinue | Where-Object {$_.Name -like '*engtype_3D*'} | Measure-Object UtilizationPercentage -Sum).Sum
"$d|$n|$g"`;
async function pollExtra() {
  const r = await ps(EXTRA_SCRIPT, 15000);
  if (r.ok) {
    const [d, n, g] = r.out.split('|').map(Number);
    extra = { Disco: Math.min(100, d || 0), Rede: Math.min(100, ((n || 0) * 8) / 1e6), GPU: Math.min(100, g || 0) };
  }
  setTimeout(pollExtra, 2000);
}

// ---------- Limpeza ----------
async function dirSize(dir) {
  let total = 0;
  let entries = [];
  try { entries = await fs.promises.readdir(dir, { withFileTypes: true }); } catch { return 0; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    try {
      if (e.isDirectory()) total += await dirSize(p);
      else total += (await fs.promises.stat(p)).size;
    } catch {}
  }
  return total;
}
async function cleanTemp() {
  let freed = 0;
  for (const dir of TEMP_DIRS) {
    let entries = [];
    try { entries = await fs.promises.readdir(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      const size = e.isDirectory() ? await dirSize(p) : (await fs.promises.stat(p).catch(() => ({ size: 0 }))).size;
      try { await fs.promises.rm(p, { recursive: true, force: true }); freed += size; } catch {} // arquivos em uso são ignorados
    }
  }
  return freed;
}

const TRIM_SCRIPT = `
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class W{[DllImport("psapi.dll")]public static extern int EmptyWorkingSet(IntPtr h);}'
Get-Process | ForEach-Object { try { [void][W]::EmptyWorkingSet($_.Handle) } catch {} }`;

ipcMain.handle('stats', () => {
  const total = os.totalmem(), free = os.freemem();
  return {
    CPU: cpuLoad(), RAM: Math.round((1 - free / total) * 100), ...extra,
    ghz: (os.cpus()[0].speed / 1000).toFixed(1), cpuName: os.cpus()[0].model.trim(),
    threads: os.cpus().length, totalGb: (total / 1073741824).toFixed(1)
  };
});
ipcMain.handle('junk', async () => {
  let t = 0; for (const d of TEMP_DIRS) t += await dirSize(d);
  return t / 1048576;
});
ipcMain.handle('clean', async () => (await cleanTemp()) / 1048576);
ipcMain.handle('trim', async () => (await ps(TRIM_SCRIPT)).ok);
ipcMain.handle('plan', async () => {
  const r = await ps('(powercfg /getactivescheme)');
  return /8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c/i.test(r.out);
});
ipcMain.handle('highperf', async () => (await ps('powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c')).ok);
ipcMain.handle('restoreCount', async () => {
  const r = await ps('@(Get-ComputerRestorePoint -ErrorAction Stop).Count');
  return r.ok && /^\d+$/.test(r.out) ? Number(r.out) : null;
});
ipcMain.handle('restoreCreate', async () => {
  const r = await ps('Checkpoint-Computer -Description "Fefeu Control" -RestorePointType MODIFY_SETTINGS -ErrorAction Stop');
  return { ok: r.ok, err: r.err };
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 600,
    backgroundColor: '#070d1c', title: 'Fefeu Control', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile('index.html');
}
app.whenReady().then(() => { createWindow(); pollExtra(); });
app.on('window-all-closed', () => app.quit());
