const { contextBridge, ipcRenderer } = require('electron');
const call = (c) => (...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('api', {
  stats: call('stats'), junk: call('junk'), clean: call('clean'), trim: call('trim'),
  plan: call('plan'), highperf: call('highperf'),
  restoreCount: call('restoreCount'), restoreCreate: call('restoreCreate')
});
