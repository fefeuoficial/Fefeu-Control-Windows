@echo off
cd /d "%~dp0"
call npm install
call npm run build
echo.
echo Pronto! O Fefeu Control.exe esta na pasta "dist".
pause
